# VoltiShop

Tienda en línea de electrónicos hecha en un solo archivo HTML (sin dependencias).

## Características
- 50 productos en 8 categorías, con buscador y filtros
- Modo claro y oscuro, diseño adaptable a teléfono y PC
- Registro e inicio de sesión (administrador incluido: `admin` / `admin123`)
- Usuario normal: carrito y código de pago ficticio y único
- Administrador: editar precio y cantidad, añadir y eliminar productos, subir fotos, ver historial de pedidos

## Uso
Abre `voltishop.html` en el navegador.

## Notas
Los datos se guardan en el navegador (localStorage). Las contraseñas no están cifradas: es una demo, no para producción.
